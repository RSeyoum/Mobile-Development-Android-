package com.example.weatherapp2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController

/**
 * A simple [Fragment] subclass.
 * Use the [WeatherFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class WeatherFragment : Fragment() {

    val viewModel: WeatherViewModel by activityViewModels<WeatherViewModel>()

    lateinit var search_button: Button
    lateinit var save_button: Button
    lateinit var cancel_button: Button
    lateinit var name_text: EditText
    lateinit var city_text: TextView
    lateinit var temp_text: TextView
    lateinit var hum_text: TextView
    lateinit var press_text: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        search_button = view.findViewById(R.id.search_button)
        save_button = view.findViewById(R.id.save_button)
        cancel_button = view.findViewById(R.id.cancel_button)
        name_text = view.findViewById(R.id.name_text)
        city_text = view.findViewById(R.id.city_text)
        temp_text = view.findViewById(R.id.temp_text)
        hum_text = view.findViewById(R.id.hum_text)
        press_text = view.findViewById(R.id.press_text)

        search_button.setOnClickListener {
            if (name_text.text.isNotEmpty()) {
                viewModel.apiManager.value?.fetchWeather(name_text.text.toString())
            }
        }

        save_button.setOnClickListener {
            viewModel.saveCurrentCityToDatabase()
            findNavController().navigate(R.id.action_global_listFragment)

        }

        cancel_button.setOnClickListener {

            findNavController().navigate(R.id.action_global_listFragment)
        }

        // This shows the information
        viewModel.currentCity.observe(viewLifecycleOwner, {
            city_text.text = it.name
            temp_text.text = "${it.temperature} ℉"
            hum_text.text = "${it.humidity}%"
            press_text.text = it.pressure.toString()
        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_weather, container, false)
    }
}