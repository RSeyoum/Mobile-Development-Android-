package com.example.weatherapp2

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class WeatherViewModel: ViewModel() {

    val apiManager = MutableLiveData<APIManager>()
    val savedCityList = MutableLiveData<Array<City>>() // List of cities from database
    val currentCity = MutableLiveData<City>() // Current search result

    // Wont get lost here
    val database = MutableLiveData<WeatherDB>()

    init {
        apiManager.value = APIManager(this)
        savedCityList.value = emptyArray()
    }

    fun setCurrentCity(city: City) {
        currentCity.value = city
        currentCity.postValue(city)
    }

    fun updateList(){
        val list = database.value?.weatherDAO()?.getAll()

        savedCityList.value = list?.toTypedArray()

        // automatically updates the recycler list
        savedCityList.postValue(list?.toTypedArray())
    }

    fun saveCurrentCityToDatabase(){

        if(currentCity.value != null) {
            database.value?.weatherDAO()?.insert(currentCity.value!!)
        }

        updateList()
    }

    fun deleteCity(city: City){
        database.value?.weatherDAO()?.delete(city)

        updateList()
    }

    fun deleteAll(){
        database.value?.weatherDAO()?.deleteAll()

        updateList()
    }
}