package com.example.weatherapp2

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController

class MainActivity : AppCompatActivity() {

    val viewModel : WeatherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // This will get destroyed
        // var db = WeatherDB.getDBObject(applicationContext)

        // Instead we should do this
        viewModel.database.value = WeatherDB.getDBObject(applicationContext)

        // call this function whenever the database is ready
        viewModel.updateList()

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu, menu)

        return true
    }


    // Use for assignment #2
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection

        // Checks which item is being clicked
        if (item.itemId == R.id.add_button) {
            findNavController(R.id.nav_host_frag).navigate(R.id.action_global_weatherFragment)
            return true
        } else {
            return super.onOptionsItemSelected(item)
        }

        /*
        else if(item.itemId == R.id.info_button){
            return true
        }
         */
    }
}