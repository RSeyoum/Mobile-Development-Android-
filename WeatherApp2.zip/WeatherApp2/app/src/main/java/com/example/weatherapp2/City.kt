package com.example.weatherapp2

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weatherTable")
class City {

    // city name can not be duplicated

    @PrimaryKey
    var name = "city name"
    var temperature = 0.0
    var pressure = 0
    var humidity = 0
}