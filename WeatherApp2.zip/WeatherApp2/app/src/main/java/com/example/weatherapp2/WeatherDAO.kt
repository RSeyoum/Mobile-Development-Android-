package com.example.weatherapp2

import androidx.room.*

// Interacts with the database

@Dao
interface WeatherDAO {

    // it searches the primary key, which in our case is the city name

    @Query("SELECT * FROM weatherTable")
    fun getAll(): List<City>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(city: City)

    @Delete
    fun delete(city: City)

    @Query("DELETE FROM weatherTable")
    fun deleteAll()
}